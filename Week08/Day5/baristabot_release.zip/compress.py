# compress_project.py

import shutil
import os
import sys

def zip_project(src_dir: str, output_filename: str):
    """
    Archive un dossier complet en ZIP avec compression.
    Exclut uniquement les dossiers "__pycache__" et fichiers .pyc.
    """
    # Vérifie que le dossier source existe
    if not os.path.isdir(src_dir):
        print(f"Erreur : le répertoire source '{src_dir}' n'existe pas.")
        sys.exit(1)

    # Crée un dossier temporaire en filtrant les fichiers indésirables
    temp = output_filename + "_temp"
    if os.path.exists(temp):
        shutil.rmtree(temp)
    shutil.copytree(src_dir, temp, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.git', '*.env'))

    # Archive avec compression ZIP
    archive_name = shutil.make_archive(output_filename, 'zip', root_dir=temp)
    print(f"✅ Archive créée : {archive_name}")

    # Nettoyage du dossier temporaire
    shutil.rmtree(temp)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python compress_project.py <source_dir> <output_name>")
        sys.exit(1)

    src = sys.argv[1]
    out = sys.argv[2]
    zip_project(src, out)
