```markdown
# BaristaBot ☕️

BaristaBot est un agent conversationnel construit avec **LangGraph** et l’API **Gemini** (via LangChain), conçu pour simuler un kiosque de commande de café. Le bot permet de consulter le menu, ajouter des boissons, confirmer et finaliser la commande de manière interactive.

---

## 🚀 Fonctionnalités clés

- Consultation dynamique du menu via un outil `get_menu`
- Ajout d’articles au panier avec modificateurs (lait, sucre…)
- Affichage, confirmation (`get_order`, `confirm_order`) et placement de commande (`place_order`)
- Interface de chat en boucle (humain ↔ chatbot ↔ tool ↔ ordering)
- Gestion des fautes de frappe courantes et suggestions
- Système de sortie propre via `q`, `quit`, `exit`

---

## 📁 Structure du projet

```

projet\_baristabot/
├── baristabot/
│   ├── **init**.py
│   ├── state.py              # Schéma `OrderState`
│   ├── tools.py              # Outils `@tool`
│   ├── nodes.py              # Nœuds du graphe
│   └── agent.py              # Construction & compilation du graph
├── test\_scenario.py          # Scénario complet de test
├── load\_env\_test.py          # Vérification des clés API
├── .env                      # Clés `GOOGLE_API_KEY`, `LANGSMITH_API_KEY`
├── requirements.txt
└── langgraph.json            # Config pour `langgraph dev`

````

---

## ⚙️ Installation

1. Clone le projet :

   ```bash
   git clone <URL>
   cd projet_baristabot
````

2. Crée et active un environnement virtuel :

   ```bash
   python3 -m venv venv
   # Windows PowerShell
   .\venv\Scripts\Activate.ps1
   ```

3. Installe les dépendances :

   ```bash
   pip install -r requirements.txt
   ```

4. Installe les outils de développement LangGraph :

   ```bash
   pip install langgraph-cli[inmem]
   ```

5. Crée un fichier `.env` :

   ```env
   GOOGLE_API_KEY=<TA_CLE_GEMINI>
   LANGSMITH_API_KEY=<TA_CLE_LANGSMITH>  # facultatif
   ```

---

## 📦 Usage

### 🔹 Mode interactif (LangGraph Studio)

```bash
langgraph dev
```

* Accède à l’interface graphique de LangGraph Studio via l’URL fournie.
* Teste en direct le flux conversationnel avec visualisation des nœuds et transitions.

### 🔹 Ligne de commande

Message d’accueil minimal :

```bash
python -c "from baristabot.agent import compiled; print([m.content for m in compiled.invoke({'messages': []})['messages']])"
```

Scénario complet de test (avec `test_scenario.py`) :

```bash
python test_scenario.py
```

---

## 🧠 Aperçu du scénario complet

| Action                  | Attendu du bot                          |
| ----------------------- | --------------------------------------- |
| “What’s on the menu?”   | Renvoie la liste des boissons et modifs |
| “A latte with oat milk” | Ajoute l’article à la commande          |
| “Show me order”         | Affiche la commande actuelle            |
| “Yes”                   | Confirme et place la commande           |
| “q”                     | Termine la session proprement           |

---

## 🧠 Technologies & dépendances

* **LangGraph** (v0.6.x) – Orchestration du graphe
* **LangChain - chat Gemini** (`langchain-google-genai`)
* **dotenv** – Chargement sécurisé des clés API
* **Python 3.11+**

---

## 🧩 Configurations supplémentaires

* LangSmith est activable via `.env` (`LANGSMITH_TRACING=true`) pour debug visuel (optional).
* Fichier `setup.py` pour installation en mode editable si besoin.

---

## 🤖 Pour les contributeurs IA

* Ajoute de nouveaux outils via `@tool` avec docstrings
* Étends les cas d’usage du bot (options personnalisées, mémoire utilisateur, etc.)
* Implémente des tests unitaires pour chaque nœud ou outil

---

## 🧾 Licence & crédits

* Projet éducatif open‑source pour un **bootcamp génératif AI**
* License : MIT (ou celle de ton choix)
* Références : tutoriel officiel BaristaBot (LangGraph + Gemini Day 3), official LangChain & LangGraph docs

---

## ✅ En résumé

* **BaristaBot** est prêt à être exécuté et testé immédiatement
* Documentation claire, tests automatisés (via `test_scenario.py`)
* Architecture modulaire adaptée à un contexte de formation en IA générative

---

📚 Pour toute question ou extension, n’hésite pas à me demander : je peux t’aider à ajouter des tests unitaires, un front-end (Streamlit ou Flask), ou à connecter une base de données !
