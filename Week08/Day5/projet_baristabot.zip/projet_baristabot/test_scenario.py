from baristabot.agent import compiled
from pprint import pprint

def run_test_scenario(inputs):
    # initial state
    state = compiled.invoke({"messages": []})
    pprint([m.content if hasattr(m, 'content') else str(m) for m in state["messages"]])

    for user_input in inputs:
        # simule message utilisateur
        state["messages"].append(("user", user_input))
        state = compiled.invoke(state)
        # affiche messages produits par l'agent
        pprint([m.content if hasattr(m, 'content') else str(m) for m in state["messages"]])

    # Affiche état final
    print("\nÉtat final :")
    print("Order:", state.get("order"))
    print("Finished:", state.get("finished"))

if __name__ == "__main__":
    test_inputs = [
        "What's on the menu?",
        "I'll take a latte with oat milk",
        "Add a cappuccino with almond milk, please",
        "Show me order",
        "Yes",
        # or "No" to cancel confirmation
    ]
    run_test_scenario(test_inputs)
