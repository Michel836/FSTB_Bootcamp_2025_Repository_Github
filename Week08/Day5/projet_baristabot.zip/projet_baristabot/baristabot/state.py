# baristabot/state.py

from typing import Annotated
from typing_extensions import TypedDict
from langgraph.graph.message import add_messages

class OrderState(TypedDict):
    """Représente l'état de la conversation et de la commande."""
    messages: Annotated[list, add_messages]
    order: list[str]
    finished: bool
    menu_shown: bool  # Indique si le menu a déjà été montré au client
