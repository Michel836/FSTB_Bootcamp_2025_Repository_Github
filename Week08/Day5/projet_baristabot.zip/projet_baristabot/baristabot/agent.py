# baristabot/agent.py

from dotenv import load_dotenv
load_dotenv()

from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import ToolNode

from baristabot.state import OrderState
from baristabot.nodes import chatbot_with_tools, human_node, order_node
from baristabot.tools import get_menu, add_to_order, confirm_order, get_order, clear_order, place_order

from langchain_google_genai import ChatGoogleGenerativeAI

# 🔧 LLM configuré et bindé avec tous les outils
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash-latest")
tools = [get_menu, add_to_order, confirm_order, get_order, clear_order, place_order]
llm_with_tools = llm.bind_tools(tools)

# 🔁 Noeud chatbot avec outils
def chatbot_node(state: OrderState) -> OrderState:
    from langchain_core.messages.ai import AIMessage
    from baristabot.nodes import BARISTABOT_SYSINT, WELCOME_MSG

    if state.get("messages"):
        msg = llm_with_tools.invoke([BARISTABOT_SYSINT] + state["messages"])
    else:
        msg = AIMessage(content=WELCOME_MSG)

    return state | {"messages": [msg]}

# 🧰 ToolNode (outils automatiques seulement)
tool_node = ToolNode([get_menu])  # Only stateless tools ici

# 🔀 Routage
def maybe_route_to_tools(state: OrderState) -> str:
    if state.get("finished", False):
        return END
    msg = state["messages"][-1]
    if hasattr(msg, "tool_calls") and msg.tool_calls:
        name = msg.tool_calls[0]["name"]
        if name == "get_menu":
            return "tools"
        else:
            return "ordering"
    return "human"

def maybe_exit_human_node(state: OrderState) -> str:
    return END if state.get("finished", False) else "chatbot"

# 🧠 Construction du graphe
graph = StateGraph(OrderState)
graph.add_node("chatbot", chatbot_node)
graph.add_node("human", human_node)
graph.add_node("tools", tool_node)
graph.add_node("ordering", order_node)

graph.add_conditional_edges("chatbot", maybe_route_to_tools)
graph.add_conditional_edges("human", maybe_exit_human_node)
graph.add_edge("tools", "chatbot")
graph.add_edge("ordering", "chatbot")
graph.add_edge(START, "chatbot")

compiled = graph.compile()

# ▶️ Exécution en mode CLI
if __name__ == "__main__":
    from pprint import pprint
    state = {"messages": []}
    while not state.get("finished", False):
        state = compiled.invoke(state)
    print("\n--- Conversation terminée ---")
    pprint(state)
