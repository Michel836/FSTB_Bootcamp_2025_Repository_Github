# baristabot/tools.py

from langchain_core.tools import tool
from collections.abc import Iterable

@tool
def get_menu() -> str:
    """Return the current coffee menu as a string."""
    return """
MENU:
Coffee Drinks: Espresso, Americano, Cold Brew
Milk Drinks: Latte, Cappuccino, Flat White
Tea Drinks: English Breakfast Tea, Green Tea, Earl Grey
Other Drinks: Hot Chocolate, Steamer

Modifiers:
Milk options: Whole, 2%, Oat, Almond (soy unavailable today)
Espresso shots: Single, Double, Triple
Caffeine: Regular (default), Decaf
Temperature: Hot (default), Iced
Sweeteners: vanilla, hazelnut, caramel, sugar-free vanilla
Special requests: extra hot, extra foam, half-caff, etc.
"""

@tool
def add_to_order(drink: str, modifiers: Iterable[str]) -> str:
    """Add a drink with optional modifiers to the order and return the updated summary."""
    return ""

@tool
def confirm_order() -> str:
    """Prompt the user to confirm the current order contents."""
    return ""

@tool
def get_order() -> str:
    """Return the current list of ordered items."""
    return ""

@tool
def clear_order() -> None:
    """Remove all items from the current order."""
    return None

@tool
def place_order() -> int:
    """Submit the order and return an estimated preparation time in minutes."""
    return 0



