# baristabot/nodes.py

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages.ai import AIMessage
from langchain_core.messages.tool import ToolMessage

from baristabot.state import OrderState

# LLM setup
llm = ChatGoogleGenerativeAI(model="gemini-1.5-flash-latest")

# System instruction and welcome message
BARISTABOT_SYSINT = (
    "system",
    "You are BaristaBot, an AI cafe assistant. Answer only about menu items. "
    "Add items to the order, confirm with the user, and finalize the order when done. "
    "Use available tools (get_menu, add_to_order, confirm_order, clear_order, place_order, get_order)."
)
WELCOME_MSG = "Welcome to the BaristaBot cafe. Type `q` to quit. How may I serve you today?"

def chatbot_with_tools(state: OrderState) -> OrderState:
    """Chat node with tool support and welcome message."""
    if state.get("messages"):
        new_msg = llm.invoke([BARISTABOT_SYSINT] + state["messages"])
    else:
        new_msg = AIMessage(content=WELCOME_MSG)

    defaults = {"order": [], "finished": False, "menu_shown": False}
    return defaults | state | {"messages": [new_msg]}


def human_node(state: OrderState) -> OrderState:
    """Node simulating human input/output."""
    last = state["messages"][-1]
    print("Model:", last.content)

    user_input = input("User: ").strip()
    if user_input.lower() in {"q", "quit", "exit", "goodbye", "bye"}:
        state["finished"] = True

    return state | {"messages": [("user", user_input)]}


def order_node(state: OrderState) -> OrderState:
    """Handles updates to the order state based on tool calls."""
    msg = state["messages"][-1]
    tool_calls = getattr(msg, "tool_calls", []) or []
    order = state.get("order", [])
    outbound = []
    finished = False

    for call in tool_calls:
        name = call["name"]
        args = call.get("args", {}) or {}

        try:
            if name == "add_to_order":
                drink = args.get("drink", "")
                mods = args.get("modifiers", [])
                order.append(f"{drink} ({', '.join(mods) if mods else 'no modifiers'})")
                resp = "\n".join(order)

            elif name == "confirm_order":
                print("Your order so far:")
                for item in order:
                    print("-", item)
                resp = input("Is this correct? ")

            elif name == "get_order":
                resp = "\n".join(order) if order else "(no order)"

            elif name == "clear_order":
                order.clear()
                resp = "(order cleared)"

            elif name == "place_order":
                print("Sending order to kitchen!")
                print("Order summary:")
                for item in order:
                    print("-", item)
                resp = f"Order placed successfully. Estimated time: 3 minutes."
                finished = True

            else:
                raise ValueError(f"Unknown tool call: {name}")

        except Exception as e:
            resp = f"Error in tool {name}: {e}"

        outbound.append(
            ToolMessage(
                content=resp,
                name=name,
                tool_call_id=call.get("id"),
            )
        )

    return {"messages": outbound, "order": order, "finished": finished}
