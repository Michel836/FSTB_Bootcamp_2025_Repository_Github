# main.py

from baristabot.agent import compiled

def run_bot():
    state = {"messages": []}
    while not state.get("finished", False):
        state = compiled.invoke(state)

if __name__ == "__main__":
    run_bot()
