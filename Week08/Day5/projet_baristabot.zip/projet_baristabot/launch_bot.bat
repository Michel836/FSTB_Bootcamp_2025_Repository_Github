@echo off
REM Place cette ligne tout en début du script
cd /D "%~dp0" || (
  echo Erreur : impossible de rejoindre le dossier du script.
  pause
  exit /b
)

REM Active le virtualenv si tu en as un (modifie le nom si besoin)
if exist "venv\Scripts\activate.bat" (
  call "venv\Scripts\activate.bat"
)

REM Lance le bot via main.py
python main.py

pause

