---

````markdown
# 🎯 BaristaBot – AI Cafe Ordering Agent

BaristaBot is a conversational agent built using **LangGraph** and **Gemini (via LangChain)**, designed to simulate a hands‑free cafe ordering kiosk. It supports menu viewing, order customization, confirmation, and finalization through natural language interaction.

---

## ✨ Features

- Interactive chat loop with role‑based nodes: **chatbot ↔ human ↔ tools ↔ ordering**
- Dynamic **menu tool** (`get_menu`) providing current items and modifiers
- Structured order management: adding items, requesting order review, clearing or placing orders
- Typo correction and clarifications (e.g., “cofee” → “coffee”)
- Graceful exit via `q`, `quit`, `exit`, or `bye`
- Configurable pricing via hypothetical values (optional `get_price` tool)

---

## 📂 Repository Structure

```text
projet_baristabot/
├── baristabot/
│   ├── __init__.py
│   ├── state.py        # TypedDict OrderState with messages, order, finished, menu_shown
│   ├── tools.py        # @tool definitions (get_menu, add_to_order, etc.)
│   ├── nodes.py        # Node functions controlling conversation and state
│   └── agent.py        # Graph construction and compilation
├── main.py             # Interactive CLI runner
├── test_scenario.py    # Predefined conversation script
├── compress_inplace.py # For ZIP packaging
├── launch_bot.bat      # Launches bot via double-click on Windows
├── .env                # Contains GOOGLE_API_KEY, LANGSMITH_API_KEY
├── requirements.txt    # Project dependencies
└── README.md           # This file
````

---

## 🧰 Installation

1. Clone the project:

   ```bash
   git clone <your_repo_url>
   cd projet_baristabot
   ```

2. Create and activate a virtual environment:

   ```bash
   python3 -m venv venv
   source venv/bin/activate   # macOS/Linux
   .\venv\Scripts\activate    # Windows PowerShell
   ```

3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file:

   ```env
   GOOGLE_API_KEY=<YOUR_GEMINI_KEY>
   LANGSMITH_API_KEY=<YOUR_LANGSMITH_KEY>  # optional
   ```

---

## 🚀 Usage

### ✅ Interactive Mode (CLI)

```bash
python main.py
```

Chat with the agent live through the console until you type `q` or `bye`.

### 📜 Test Mode

```bash
python test_scenario.py
```

Executes a scripted conversation with validations, ending in order placement.

### 🛠 ZIP Packaging

```bash
python compress_inplace.py projet_baristabot baristabot_release
```

Creates `baristabot_release.zip` in the parent folder, excluding `.git`, `.env`, and caches.

---

## ⚙️ Configuration

* Add or modify tools in `tools.py` (e.g., implement `get_price`)
* Schema fields in `OrderState` support features like:

  * `menu_shown` prevents repeated `get_menu` calls
  * `finished` triggers clean graph exit via `END`
* Graph logic resides in `agent.py` with custom routing:

  * `maybe_route_to_tools`
  * `maybe_exit_human_node`

---

## 🏗️ Technology Stack

* **Python ≥ 3.9**
* **LangGraph** (v0.6.x) for graph-driven execution
* **LangChain (Google Gemini)** via `langchain-google-genai`
* **python-dotenv** for environment loading

---

## 📖 Example Conversation Flow

| User Input              | Bot Response                                          |
| ----------------------- | ----------------------------------------------------- |
| “menu”                  | Prints the menu via `get_menu`                        |
| “A latte with oat milk” | Uses `add_to_order`, then asks for confirmation       |
| “Yes”                   | Prompts price, then finalizes order via `place_order` |
| “q”                     | Exits gracefully                                      |

The conversation updates `OrderState.order`, checks user confirmations, and ends when `order_placed` or `finished=True`.

---

## 🤝 Contribution Guidelines

* Pull requests welcome! Start an issue for major changes.
* Maintain docstrings and tool schemas when adding new features.
* Add unit tests for new nodes or tools for robustness.

---

## 🤖 Suggestions / Next Steps

Want to extend the project? Here’s some ideas:

* Add **pricing logic** via `get_price` tool
* Build a **GUI or web UI** (Streamlit, Flask, Gradio)
* Add **customer preference memory** or reward point system
* Integrate **LangSmith tracing** for debugging (`LANGSMITH_TRACING=true`)

---

## 📄 License & Credits

* **MIT License**
* Educational project built for a **Generative AI bootcamp**
* Inspired by the official LangGraph BaristaBot example and Gemini API documentation (\[turn0search0]turn0search2)

---

## ✅ Quick Start Summary

1. Clone repo → set up venv → install dependencies
2. Create `.env` with API keys
3. Run: `python main.py` or `python test_scenario.py`
4. Bundle via `compress_inplace.py` → share or upload ZIP

---

Happy developing and shipping your first generative AI agent! 🚀
Feel free to customize or extend
